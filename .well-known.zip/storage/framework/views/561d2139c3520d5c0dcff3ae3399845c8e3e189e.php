<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - T.A.M Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .stat-card { border-radius: 12px; }
        .table th { font-size: .85rem; }
        .table td { font-size: .88rem; vertical-align: middle; }
        .ewp-badge { font-size: .75rem; }
        @media (max-width: 768px) {
            .table-responsive { font-size: .80rem; }
        }
    </style>
</head>
<body class="bg-light">

    <?php
        function formatEWP($menit) {
            if ($menit <= 0) return '0 Menit';
            $hari = floor($menit / 1440);
            $sisa_menit = $menit % 1440;
            $jam = floor($sisa_menit / 60);
            $menit_akhir = $sisa_menit % 60;
            $hasil = '';
            if ($hari > 0) $hasil .= $hari . ' Hari ';
            if ($jam > 0) $hasil .= $jam . ' Jam ';
            if ($menit_akhir > 0) $hasil .= $menit_akhir . ' Menit';
            return trim($hasil);
        }
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
        <div class="container-fluid px-3">
            <a class="navbar-brand fw-bold">👔 T.A.M Laundry — Admin</a>
            <div class="d-flex align-items-center gap-2">
                <span class="text-white d-none d-sm-inline small"><?php echo e(Auth::user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="mb-0">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-danger fw-bold" type="submit">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-3 mt-3">

        <?php if(session('sukses')): ?>
            <div class="alert alert-success fw-bold shadow-sm">🎉 <?php echo e(session('sukses')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger fw-bold shadow-sm">❌ <?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="row g-3 mb-4">
            <div class="col-sm-6 col-lg-4">
                <div class="card stat-card border-0 shadow-sm bg-primary text-white p-3">
                    <small class="text-uppercase fw-bold opacity-75" style="font-size:.75rem;">💰 Total Pendapatan (Lunas)</small>
                    <h3 class="fw-bold mt-1 mb-0">Rp <?php echo e(number_format($total_pendapatan, 0, ',', '.')); ?></h3>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="card stat-card border-0 shadow-sm bg-warning text-dark p-3">
                    <small class="text-uppercase fw-bold opacity-75" style="font-size:.75rem;">🧺 Antrean Cucian Aktif</small>
                    <h3 class="fw-bold mt-1 mb-0"><?php echo e($pesanan_aktif); ?> Pesanan</h3>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card stat-card border-0 shadow-sm bg-success text-white p-3 h-100 d-flex flex-column justify-content-center">
                    <div class="d-flex gap-2">
                        <a href="<?php echo e(route('admin.export')); ?>" class="btn btn-light btn-sm fw-bold flex-fill">
                            📥 Unduh Laporan CSV
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold py-3 border-bottom">
                        🗂️ Manajemen Pesanan & Validasi Timbangan
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0 text-center align-middle">
                                <thead class="table-dark">
                                    <tr>
                                        <th>No. Resi</th>
                                        <th class="text-start">Pelanggan</th>
                                        <th>Layanan</th>
                                        <th>Aksi / Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="fw-bold text-secondary small"><?php echo e($t->no_resi); ?></td>
                                        <td class="text-start">
                                            <span class="fw-bold d-block"><?php echo e($t->user->name); ?></span>
                                            <small class="text-muted"><?php echo e($t->user->no_wa); ?></small>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark border d-block mb-1"><?php echo e($t->layanan->nama_layanan); ?></span>
                                            <span class="badge bg-secondary small"><?php echo e($t->metode_kirim); ?></span>
                                        </td>
                                        <td>
                                            <?php if($t->status_pengerjaan == 'Menunggu Penjemputan'): ?>
                                                <span class="badge bg-warning text-dark w-100 py-2">🛵 Kurir Sedang Menjemput</span>
                                                <?php if($t->nama_kurir): ?>
                                                <small class="text-muted d-block mt-1">Kurir: <?php echo e($t->nama_kurir); ?></small>
                                                <?php endif; ?>
                                            <?php elseif($t->status_pengerjaan == 'Menunggu Timbangan'): ?>
                                                <form action="<?php echo e(url('/admin/input-berat/' . $t->no_resi)); ?>" method="POST" class="d-flex justify-content-center gap-1 align-items-center">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="number" step="0.1" min="0.1" name="berat" class="form-control form-control-sm" placeholder="Kg / Pcs" style="width:90px;" required>
                                                    <button type="submit" class="btn btn-danger btn-sm fw-bold text-nowrap">⚖️ Timbang</button>
                                                </form>
                                            <?php else: ?>
                                                
                                                
                                                <?php if($t->pembayaran && $t->pembayaran->status_pembayaran == 'Belum Lunas' && $t->metode_pembayaran == 'Tunai'): ?>
                                                    <form action="<?php echo e(url('/admin/konfirmasi-lunas/' . $t->no_resi)); ?>" method="POST" class="mb-2" onsubmit="return confirm('Yakin uang tunai sudah Anda terima dari kurir/pelanggan?');">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-success btn-sm w-100 fw-bold">💵 Tandai Lunas (Tunai)</button>
                                                    </form>
                                                <?php endif; ?>

                                                <form action="<?php echo e(url('/admin/update-status/' . $t->no_resi)); ?>" method="POST" class="d-flex justify-content-center gap-1 mb-1">
                                                    <?php echo csrf_field(); ?>
                                                    <select name="status" class="form-select form-select-sm" style="width:130px;" required>
                                                        <option value="Sedang Dicuci"   <?php echo e($t->status_pengerjaan == 'Sedang Dicuci'   ? 'selected' : ''); ?>>🫧 Sedang Dicuci</option>
                                                        <option value="Siap Diantar"    <?php echo e($t->status_pengerjaan == 'Siap Diantar'    ? 'selected' : ''); ?>>📦 Siap Diantar</option>
                                                        <option value="Selesai"         <?php echo e($t->status_pengerjaan == 'Selesai'         ? 'selected' : ''); ?>>✅ Selesai</option>
                                                    </select>
                                                    <button type="submit" class="btn btn-dark btn-sm fw-bold">OK</button>
                                                </form>

                                                <small class="text-success fw-bold d-block">
                                                    Rp <?php echo e(number_format($t->pembayaran->total_harga ?? 0, 0, ',', '.')); ?> | <?php echo e($t->total_berat); ?> Unit
                                                </small>
                                                <small class="text-info fw-bold ewp-badge">
                                                    ⏱ Estimasi: <?php echo e(formatEWP($t->ewp_menit)); ?>

                                                </small>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-5 text-muted"><em>Belum ada data transaksi.</em></td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold py-3 border-bottom text-primary">
                        📅 Transaksi Masuk Hari Ini
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush" style="max-height: 480px; overflow-y: auto;">
                            <?php $__empty_1 = true; $__currentLoopData = $laporan_hari_ini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center py-3 px-3">
                                <div>
                                    <span class="fw-bold text-dark d-block"><?php echo e($h->user->name); ?></span>
                                    <small class="text-muted"><?php echo e($h->no_resi); ?> (<?php echo e($h->metode_pembayaran); ?>)</small><br>
                                    <small class="text-muted"><?php echo e($h->layanan->nama_layanan); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="badge <?php echo e(($h->pembayaran->status_pembayaran ?? '') == 'Lunas' ? 'bg-success' : (($h->pembayaran->status_pembayaran ?? '') == 'Belum Lunas' ? 'bg-danger' : 'bg-secondary')); ?> rounded-pill d-block mb-1">
                                        <?php echo e($h->pembayaran->status_pembayaran ?? 'Belum Ditimbang'); ?>

                                    </span>
                                    <small class="text-muted fw-bold"><?php echo e($h->total_berat ?? '?'); ?> Unit</small>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item text-center py-4 text-muted">
                                <em>Belum ada transaksi hari ini.</em>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>

        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\tam-laundry\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>