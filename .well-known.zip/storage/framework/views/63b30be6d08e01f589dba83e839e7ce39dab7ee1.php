<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dasbor Saya - T.A.M Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .riwayat-card { border-radius: 20px; transition: transform 0.2s, box-shadow 0.2s; border: none; }
        .riwayat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.08); }
        .badge-status { border-radius: 12px; padding: 6px 12px; font-weight: 600; }
        .navbar-custom { background: linear-gradient(90deg, #198754 0%, #20c997 100%); border-radius: 0 0 20px 20px; padding: 15px 0;}
        .price-card { border-radius: 16px; border: none; transition: transform 0.2s; }
        .price-card:hover { transform: scale(1.02); }
    </style>
</head>
<body>

    <?php
        function formatEWP($menit) {
            if ($menit <= 0) return 'Menunggu Timbangan';
            $hari = floor($menit / 1440);
            $sisa_menit = $menit % 1440;
            $jam = floor($sisa_menit / 60);
            $menit_akhir = $sisa_menit % 60;
            $hasil = '';
            if ($hari > 0) $hasil .= $hari . ' Hari ';
            if ($jam > 0) $hasil .= $jam . ' Jam ';
            if ($menit_akhir > 0) $hasil .= $menit_akhir . ' Menit';
            return trim($hasil);
        }
    ?>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold fs-4">🫧 T.A.M Laundry</a>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="mb-0">
                <?php echo csrf_field(); ?>
                <button class="btn btn-light text-success fw-bold rounded-pill px-4" type="submit">👋 Keluar</button>
            </form>
        </div>
    </nav>

    <div class="container pb-5">
        <?php if(session('sukses')): ?>
            <div class="alert alert-success fw-bold rounded-4 shadow-sm text-center">🎉 <?php echo e(session('sukses')); ?></div>
        <?php endif; ?>

        <div class="row align-items-center mb-4 bg-white p-4 rounded-4 shadow-sm mx-0">
            <div class="col-md-8 text-center text-md-start mb-3 mb-md-0">
                <h3 class="fw-bold text-dark mb-1">Halo, <?php echo e(Auth::user()->name); ?>! ✨</h3>
                <p class="text-muted mb-0">Yuk pantau cucianmu atau buat pesanan baru hari ini.</p>
            </div>
            <div class="col-md-4 text-center text-md-end">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-lg fw-bold rounded-pill shadow-sm w-100">
                    + 🧺 Pesan Laundry Baru
                </a>
            </div>
        </div>

        <h5 class="fw-bold mb-3 ms-2 mt-5">💸 Katalog Layanan & Harga</h5>
        <div class="row g-3 mb-5 mx-0">
            <div class="col-md-4 col-sm-6">
                <div class="card price-card shadow-sm h-100 bg-primary-subtle text-primary">
                    <div class="card-body text-center p-4">
                        <div style="font-size: 2.5rem; margin-bottom:10px;">👕</div>
                        <h6 class="fw-bold mb-1">Cuci Kering</h6>
                        <h4 class="fw-bold mb-0">Rp 5.000<span class="fs-6 fw-normal">/kg</span></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="card price-card shadow-sm h-100 bg-success-subtle text-success">
                    <div class="card-body text-center p-4">
                        <div style="font-size: 2.5rem; margin-bottom:10px;">✨</div>
                        <h6 class="fw-bold mb-1">Cuci Setrika</h6>
                        <h4 class="fw-bold mb-0">Rp 7.000<span class="fs-6 fw-normal">/kg</span></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card price-card shadow-sm h-100 bg-warning-subtle text-dark">
                    <div class="card-body text-center p-4">
                        <div style="font-size: 2.5rem; margin-bottom:10px;">🧼</div>
                        <h6 class="fw-bold mb-1">Cuci Satuan</h6>
                        <div class="small fw-bold opacity-75 text-start mx-auto mt-2" style="max-width: 180px;">
                            <div class="d-flex justify-content-between"><span>Karpet</span> <span>Rp 50K</span></div>
                            <div class="d-flex justify-content-between"><span>Selimut</span> <span>Rp 20K</span></div>
                            <div class="d-flex justify-content-between"><span>Mukena</span> <span>Rp 10K</span></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 mt-2">
                <div class="alert alert-info rounded-pill text-center py-2 mb-0 small border-0 shadow-sm">
                    🛵 <strong>Layanan Antar Jemput:</strong> Tersedia dengan tambahan biaya operasional Rp 7.500/pesanan.
                </div>
            </div>
        </div>

        <h5 class="fw-bold mb-3 ms-2 mt-4">📦 Riwayat Cucianmu</h5>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $riwayat_cucian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-4">
                <div class="card riwayat-card shadow-sm h-100">
                    <div class="card-body p-4">
                        
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-muted fw-bold small">#<?php echo e($t->no_resi); ?></span>
                            <span class="badge <?php echo e(($t->pembayaran && $t->pembayaran->status_pembayaran == 'Lunas') ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'); ?> badge-status">
                                <?php echo e(($t->pembayaran && $t->pembayaran->status_pembayaran == 'Lunas') ? '✅ Lunas' : '⏳ Belum Lunas'); ?>

                            </span>
                        </div>

                        <h5 class="fw-bold mb-1"><?php echo e($t->layanan->nama_layanan); ?></h5>
                        <p class="text-muted small mb-3">📅 <?php echo e(\Carbon\Carbon::parse($t->created_at)->format('d M Y')); ?> • 🛵 Kurir: <?php echo e($t->nama_kurir ?? '-'); ?></p>

                        <div class="bg-light rounded-4 p-3 mb-3 text-center">
                            <span class="d-block small text-muted mb-1">Status Saat Ini:</span>
                            <?php
                                $statusColor = match($t->status_pengerjaan) {
                                    'Menunggu Penjemputan' => 'text-warning',
                                    'Menunggu Timbangan'  => 'text-secondary',
                                    'Sedang Dicuci'        => 'text-primary',
                                    'Siap Diantar'         => 'text-info',
                                    'Selesai'              => 'text-success',
                                    default                => 'text-dark',
                                };
                            ?>
                            <strong class="<?php echo e($statusColor); ?> fs-5 d-block mb-2"><?php echo e($t->status_pengerjaan); ?></strong>
                            
                            <div class="badge bg-dark-subtle text-dark p-2 w-100">
                                ⏱️ Estimasi Selesai:<br>
                                <span class="fw-bold text-primary"><?php echo e(formatEWP($t->ewp_menit)); ?></span>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-bold fs-5 text-success">Rp <?php echo e(number_format($t->pembayaran->total_harga ?? 0, 0, ',', '.')); ?></span>
                            <a href="<?php echo e(route('struk', $t->no_resi)); ?>" class="btn btn-dark fw-bold rounded-pill px-4">
                                <?php echo e((!$t->pembayaran || $t->pembayaran->status_pembayaran == 'Belum Lunas') ? '💳 Bayar' : '🧾 Struk'); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5 bg-white rounded-4 shadow-sm">
                <div style="font-size:4rem;">🧺</div>
                <h4 class="fw-bold mt-3 text-muted">Keranjang masih kosong</h4>
                <p class="text-muted">Kamu belum pernah memesan layanan laundry kami.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\tam-laundry\resources\views/pelanggan/dashboard.blade.php ENDPATH**/ ?>