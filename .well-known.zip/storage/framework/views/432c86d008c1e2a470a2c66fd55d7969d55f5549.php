<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Kurir - T.A.M Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        #map { height: 400px; width: 100%; border-radius: 0 0 8px 8px; z-index: 1;}
        @media (max-width: 768px) { #map { height: 280px; } }
        .badge-status-jemput { background-color: #ffc107; color: #000; }
        .badge-status-antar  { background-color: #0dcaf0; color: #000; }
        .task-card { border-left: 4px solid #0d6efd; transition: box-shadow .2s; }
        .task-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.10); }
        .gmaps-btn { font-size: .80rem; }
    </style>
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
        <div class="container-fluid px-3">
            <a class="navbar-brand fw-bold" href="#">🛵 Panel Kurir T.A.M</a>
            <div class="d-flex align-items-center gap-2">
                <span class="text-white d-none d-sm-inline small">Halo, <?php echo e(Auth::user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="mb-0">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-danger fw-bold" type="submit">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container-fluid px-3 mt-3">
        <?php if(session('sukses')): ?>
            <div class="alert alert-success fw-bold shadow-sm mb-3">✅ <?php echo e(session('sukses')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger fw-bold shadow-sm mb-3">❌ <?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="row g-3">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold py-3 border-bottom">
                        📍 Peta Lokasi Tugas Aktif
                    </div>
                    <div id="map"></div>

                    <div class="card-footer bg-white border-top p-3">
                        <h6 class="fw-bold text-dark mb-2">🗺️ Navigasi ke Pelanggan (Akurat via Titik Koordinat):</h6>
                        <div class="row g-2">
                            <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $origin = urlencode("Jl. Awibitung Gg. Jembar 4 No.4, Cicadas, Kota Bandung, Jawa Barat");
                                    $destination = urlencode($t->alamat);
                                    if($t->latitude && $t->longitude){
                                        $destination = "{$t->latitude},{$t->longitude}";
                                    }
                                    $gmaps_link = "https://www.google.com/maps/dir/?api=1&origin={$origin}&destination={$destination}&travelmode=driving";
                                ?>
                                <div class="col-sm-6">
                                    <a href="<?php echo e($gmaps_link); ?>" target="_blank"
                                       class="btn btn-sm btn-outline-success w-100 fw-bold text-start text-truncate gmaps-btn">
                                        🚗 <?php echo e($t->no_resi); ?> → <?php echo e($t->user->name); ?>

                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12">
                                    <p class="text-muted small mb-0"><em>Tidak ada tugas navigasi saat ini.</em></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-bold py-3 border-bottom">
                        📋 Daftar Tugas Aktif
                        <span class="badge bg-primary rounded-pill float-end"><?php echo e($transaksi->count()); ?></span>
                    </div>
                    <div class="overflow-auto" style="max-height: 560px;">
                        <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="task-card card border-0 border-bottom m-0 rounded-0 p-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="badge bg-secondary"><?php echo e($t->no_resi); ?></span>
                                <span class="badge <?php echo e($t->status_pengerjaan == 'Menunggu Penjemputan' ? 'badge-status-jemput' : 'badge-status-antar'); ?>">
                                    <?php echo e($t->status_pengerjaan == 'Menunggu Penjemputan' ? '🛵 Jemput' : '📦 Antar'); ?>

                                </span>
                            </div>

                            <p class="fw-bold text-dark mb-1"><?php echo e($t->user->name); ?></p>
                            
                            <?php if($t->metode_pembayaran == 'Tunai' && (!$t->pembayaran || $t->pembayaran->status_pembayaran != 'Lunas')): ?>
                                <div class="alert alert-warning small py-1 px-2 mt-1 mb-2 fw-bold text-dark border-0">
                                    💵 TAGIH TUNAI: Rp <?php echo e(number_format($t->pembayaran->total_harga ?? 0, 0, ',', '.')); ?>

                                </div>
                            <?php endif; ?>

                            <?php if($t->catatan): ?>
                                <div class="alert alert-warning small py-1 px-2 mt-1 mb-2 fw-bold text-dark border-0">
                                    📝 Catatan: "<?php echo e($t->catatan); ?>"
                                </div>
                            <?php endif; ?>

                            <p class="text-muted small mb-1">📱 <?php echo e($t->user->no_wa); ?></p>
                            <p class="text-muted small mb-1">🧺 <?php echo e($t->layanan->nama_layanan); ?></p>
                            <div class="bg-light rounded p-2 small text-muted mb-2">
                                <strong>Alamat:</strong> <?php echo e($t->alamat ?? '-'); ?>

                            </div>

                            <?php if($t->latitude && $t->longitude): ?>
                                <span class="badge bg-success-subtle text-success small mb-2">📌 Koordinat tersedia</span>
                            <?php else: ?>
                                <span class="badge bg-warning-subtle text-warning small mb-2">⚠️ Koordinat belum ada</span>
                            <?php endif; ?>

                            <div class="d-flex gap-2 mt-1">
                                <?php if($t->latitude && $t->longitude): ?>
                                <button class="btn btn-primary btn-sm fw-bold w-50" onclick="fokusKeLokasi(<?php echo e($index); ?>)">
                                    🔍 Pin Peta
                                </button>
                                <?php else: ?>
                                <button class="btn btn-secondary btn-sm fw-bold w-50" disabled>
                                    🔍 Tanpa Pin
                                </button>
                                <?php endif; ?>

                                <?php if($t->status_pengerjaan == 'Menunggu Penjemputan'): ?>
                                <form action="<?php echo e(url('/admin/update-status/' . $t->no_resi)); ?>" method="POST" class="w-50 mb-0"
                                      onsubmit="return confirm('⚠️ PERHATIAN!\n\nApakah Anda yakin sudah menjemput pakaian dari pelanggan ini di lokasi? Data akan diteruskan ke Admin untuk ditimbang.');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="status" value="Menunggu Timbangan">
                                    <button type="submit" class="btn btn-warning btn-sm fw-bold w-100 text-dark">✅ Dijemput</button>
                                </form>
                                <?php elseif($t->status_pengerjaan == 'Siap Diantar'): ?>
                                <form action="<?php echo e(url('/admin/update-status/' . $t->no_resi)); ?>" method="POST" class="w-50 mb-0"
                                      onsubmit="return confirm('⚠️ PERHATIAN!\n\nApakah Anda yakin cucian ini sudah selesai diantar ke tangan pelanggan? Status pesanan akan ditutup (SELESAI).');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="status" value="Selesai">
                                    <button type="submit" class="btn btn-info btn-sm fw-bold w-100 text-dark">🏁 Selesai Diantar</button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="text-center py-5 text-muted">
                            <div style="font-size:2rem;">🎉</div>
                            <p class="mt-2"><em>Tidak ada tugas aktif saat ini.</em></p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        var map = L.map('map').setView([-6.908795278171104, 107.63908969612783], 16);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap'
        }).addTo(map);

        var iconPusat = L.divIcon({
            html: '<div style="background:#0d6efd;color:white;border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;font-size:16px;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,.3)">🏢</div>',
            className: '', iconSize: [32, 32], iconAnchor: [16, 16]
        });
        
        L.marker([-6.908795278171104, 107.63908969612783], { icon: iconPusat })
            .addTo(map)
            .bindPopup('<b>🏢 T.A.M LAUNDRY</b><br>Jl. Awibitung Gg. Jembar 4 No.4 RT 4 RW 5<br>Kel. Cicadas, Kec. Cibeunying Kidul, Kota Bandung')
            .openPopup();

        var lokasiPelanggan = [];
        var markers = [];

        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($t->latitude && $t->longitude): ?>
                lokasiPelanggan[<?php echo e($index); ?>] = [<?php echo e($t->latitude); ?>, <?php echo e($t->longitude); ?>];

                var iconPelanggan<?php echo e($index); ?> = L.divIcon({
                    html: '<div style="background:#198754;color:white;border-radius:50%;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:14px;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,.3)">📌</div>',
                    className: '', iconSize: [28, 28], iconAnchor: [14, 14]
                });

                markers[<?php echo e($index); ?>] = L.marker(
                    [<?php echo e($t->latitude); ?>, <?php echo e($t->longitude); ?>],
                    { icon: iconPelanggan<?php echo e($index); ?> }
                ).addTo(map).bindPopup(
                    '<b>📌 <?php echo e($t->user->name); ?></b><br>' +
                    'Resi: <strong><?php echo e($t->no_resi); ?></strong><br>' +
                    '<?php echo e($t->status_pengerjaan); ?><br>' +
                    '<small class="text-muted"><?php echo e($t->alamat); ?></small>'
                );
            <?php else: ?>
                lokasiPelanggan[<?php echo e($index); ?>] = null;
                markers[<?php echo e($index); ?>] = null;
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function fokusKeLokasi(index) {
            if (lokasiPelanggan[index] && markers[index]) {
                map.setView(lokasiPelanggan[index], 16);
                markers[index].openPopup();
            } else {
                alert('Koordinat lokasi pelanggan ini belum tersedia.');
            }
        }
    </script>
</body>
</html><?php /**PATH C:\laragon\www\tam-laundry\resources\views/kurir/dashboard.blade.php ENDPATH**/ ?>