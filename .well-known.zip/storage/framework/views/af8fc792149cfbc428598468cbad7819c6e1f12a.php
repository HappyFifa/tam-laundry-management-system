<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>T.A.M Laundry - Bersih, Wangi, Praktis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero-bg { background: linear-gradient(135deg, #0d6efd 0%, #0dcaf0 100%); color: white; border-radius: 0 0 40px 40px; }
        .feature-icon { font-size: 3rem; margin-bottom: 15px; }
    </style>
</head>
<body class="bg-light">

    
    <div class="hero-bg text-center py-5 shadow-sm">
        <div class="container py-5">
            <h1 class="display-4 fw-bold mb-3">🫧 T.A.M Laundry</h1>
            <p class="lead mb-4">Solusi praktis untuk pakaian bersih dan wangi. Nikmati layanan antar-jemput dan pantau status cucian Anda secara real-time!</p>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-light btn-lg fw-bold text-primary px-4 py-2 me-2 shadow-sm">Masuk / Pesan Sekarang</a>
            <a href="<?php echo e(route('register.pelanggan')); ?>" class="btn btn-outline-light btn-lg fw-bold px-4 py-2">Daftar Akun</a>
        </div>
    </div>

    
    <div class="container mt-5 pt-3 mb-5">
        <div class="row text-center g-4">
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                    <div class="feature-icon">🛵</div>
                    <h5 class="fw-bold">Antar Jemput</h5>
                    <p class="text-muted small">Kurir kami siap menjemput pakaian kotor langsung dari depan pintu rumah Anda.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                    <div class="feature-icon">⏱️</div>
                    <h5 class="fw-bold">Estimasi Akurat</h5>
                    <p class="text-muted small">Sistem kami menghitung waktu selesai secara otomatis agar Anda tidak perlu menunggu lama.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100 p-4 rounded-4">
                    <div class="feature-icon">💳</div>
                    <h5 class="fw-bold">Bayar via QRIS</h5>
                    <p class="text-muted small">Transaksi lebih mudah, cepat, dan aman menggunakan dompet digital atau m-banking.</p>
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\laragon\www\tam-laundry\resources\views/landing.blade.php ENDPATH**/ ?>