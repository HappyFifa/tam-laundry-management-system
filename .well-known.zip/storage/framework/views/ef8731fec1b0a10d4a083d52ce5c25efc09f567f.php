<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk Akun - T.A.M Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background: #f0f4f8; 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            margin: 0;
        }
        .auth-card { border-radius: 16px; max-width: 420px; margin: 0 auto; }
    </style>
</head>
<body>
    <div class="container w-100">

        <?php if(session('sukses')): ?>
            <div class="alert alert-success fw-bold text-center shadow-sm mb-3" style="max-width:420px;margin:0 auto 12px; border-radius: 12px;">
                ✅ <?php echo e(session('sukses')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger fw-bold text-center shadow-sm mb-3" style="max-width:420px;margin:0 auto 12px; border-radius: 12px;">
                ❌ <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card auth-card shadow border-0">
            <div class="card-body p-4 p-sm-5">

                <div class="text-center mb-4">
                    <h4 class="fw-bold text-success mb-0">🫧 T.A.M LAUNDRY</h4>
                    <p class="text-muted small mt-1">Silakan masuk untuk melanjutkan</p>
                </div>

                <form action="<?php echo e(route('customer.login.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label class="fw-bold form-label">Nomor WhatsApp</label>
                        <input type="text" name="no_wa"
                               class="form-control <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Contoh: 08123456789"
                               value="<?php echo e(old('no_wa')); ?>" 
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 12);"
                               required autofocus>
                        <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="fw-bold form-label">Kata Sandi</label>
                        <input type="password" name="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="••••••" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="text-end mb-3">
                        <a href="<?php echo e(route('lupa.password')); ?>" class="small text-muted text-decoration-none">
                            Lupa kata sandi?
                        </a>
                    </div>

                    <button type="submit" class="btn btn-success w-100 fw-bold py-2">
                        Masuk Sistem
                    </button>
                </form>

                <hr class="my-3">

                <div class="text-center">
                    <span class="text-muted small">Belum punya akun? </span>
                    <a href="<?php echo e(route('register.pelanggan')); ?>" class="fw-bold text-success text-decoration-none small">
                        Daftar Sekarang
                    </a>
                </div>

                <div class="text-center mt-2">
                    <a href="<?php echo e(route('login.pegawai')); ?>" class="text-muted text-decoration-none" style="font-size:.75rem;">
                        🔒 Akses Pegawai Internal
                    </a>
                </div>

            </div>
        </div>

    </div>
</body>
</html><?php /**PATH /home/tamlaund/public_html/resources/views/auth/login-pelanggan.blade.php ENDPATH**/ ?>