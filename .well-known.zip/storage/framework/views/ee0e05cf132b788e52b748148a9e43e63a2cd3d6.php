<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun - T.A.M Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background: #f0f4f8; 
            min-height: 100vh; 
            display: flex; 
            align-items: center; 
            margin: 0;
        }
        .auth-card { border-radius: 16px; max-width: 420px; margin: 0 auto; }
    </style>
</head>
<body>
    <div class="container w-100">

        <div class="card auth-card shadow border-0">
            <div class="card-body p-4 p-sm-5">

                <div class="text-center mb-4">
                    <h4 class="fw-bold text-primary mb-0">📋 DAFTAR PELANGGAN</h4>
                    <p class="text-muted small mt-1">Lengkapi data diri pendaftaran Anda</p>
                </div>

                <form action="<?php echo e(route('customer.register.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    
                    <div class="mb-3">
                        <label class="fw-bold form-label">Nama Lengkap <span class="text-danger">*</span></label>
                        <input type="text" name="nama"
                               class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Masukkan nama lengkap Anda"
                               value="<?php echo e(old('nama')); ?>" required>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="mb-3">
                        <label class="fw-bold form-label">Nomor WhatsApp Aktif <span class="text-danger">*</span></label>
                        <input type="text" name="no_wa"
                               class="form-control <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="08XXXXXXXXXX (Maks 12 Angka)"
                               value="<?php echo e(old('no_wa')); ?>" 
                               oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0, 12);"
                               required>
                        <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text text-muted small">
                            📱 Nomor ini digunakan untuk login dan menerima notifikasi otomatis.
                        </div>
                    </div>

                    
                    <div class="mb-4">
                        <label class="fw-bold form-label">Buat Kata Sandi <span class="text-danger">*</span></label>
                        <input type="password" name="password"
                               class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="Minimal 6 karakter" required>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text text-muted small">
                            🔒 Kata sandi akan dikirim ke WhatsApp Anda setelah registrasi.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 fw-bold py-2">
                        ✅ Selesaikan Pendaftaran
                    </button>
                </form>

                <hr class="my-3">

                <div class="text-center">
                    <span class="text-muted small">Sudah punya akun? </span>
                    <a href="<?php echo e(route('login')); ?>" class="fw-bold text-primary text-decoration-none small">
                        ← Masuk di sini
                    </a>
                </div>

            </div>
        </div>

    </div>
</body>
</html><?php /**PATH C:\laragon\www\tam-laundry\resources\views/auth/register-pelanggan.blade.php ENDPATH**/ ?>