<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    protected $fillable = ['name', 'email', 'no_wa', 'password', 'role'];
    protected $hidden = ['password', 'remember_token'];

    public function transaksi()
    {
        return $this->hasMany(Transaction::class, 'user_id');
    }
}