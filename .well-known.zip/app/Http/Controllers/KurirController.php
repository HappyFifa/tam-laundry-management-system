<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;

class KurirController extends Controller
{
    // ==========================================
    // MENAMPILKAN HALAMAN DASBOR KURIR
    // ==========================================
    public function dashboard()
    {
        // [DIPERBAIKI] MENAMBAHKAN 'Siap Diantar' AGAR MUNCUL DI PETA KURIR
        $transaksi = Transaction::with(['user', 'layanan'])
            ->whereIn('status_pengerjaan', ['Menunggu Penjemputan', 'Siap Diantar', 'Sedang Diantar'])
            ->orderBy('created_at', 'desc')
            ->get();
        
        return view('kurir.dashboard', compact('transaksi'));
    }

    // ==========================================
    // FUNGSI KONFIRMASI PENJEMPUTAN / PENGANTARAN
    // (Sesuai dengan Sequence Diagram Halaman 12)
    // ==========================================
    public function konfirmasiJemput($resi)
    {
        // 1. Cari data transaksi beserta relasi user berdasarkan No Resi
        $transaksi = Transaction::with('user')->where('no_resi', $resi)->first();

        // 2. Jika data tidak ditemukan, kembalikan error
        if (!$transaksi) {
            return back()->with('error', 'Data pesanan tidak ditemukan!');
        }

        // 3. Logika Update Status (Sesuai Diagram)
        if ($transaksi->status_pengerjaan == 'Menunggu Penjemputan') {
            
            // Kurir mengambil baju kotor -> Status berubah ke Menunggu Timbangan
            $transaksi->update([
                'status_pengerjaan' => 'Menunggu Timbangan'
            ]);
            return back()->with('sukses', 'Pesanan berhasil dijemput! Status sekarang: Menunggu Timbangan.');

        } elseif (in_array($transaksi->status_pengerjaan, ['Siap Diantar', 'Sedang Diantar'])) {
            
            // Kurir mengantar baju bersih -> Status berubah ke Selesai
            $transaksi->update([
                'status_pengerjaan'  => 'Selesai',
                'waktu_selesai_cuci' => now() // Opsional: catat waktu selesai
            ]);

            // ==========================================================
            // KIRIM WHATSAPP OTOMATIS SAAT SELESAI DIANTAR
            // ==========================================================
            if ($transaksi->user && $transaksi->user->no_wa) {
                $pesan = "Halo *{$transaksi->user->name}*!\n\n"
                       . "🫧 Pesanan T.A.M Laundry Anda (*#{$transaksi->no_resi}*) telah *SELESAI DIANTAR* dan sampai di alamat tujuan.\n\n"
                       . "Terima kasih telah mempercayakan pakaian bersih & wangi Anda kepada *T.A.M Laundry*! 🙏\n\n"
                       . "🌐 Cek riwayat: " . url('/login');

                $this->kirimWhatsApp($transaksi->user->no_wa, $pesan);
            }

            return back()->with('sukses', 'Pesanan berhasil diantar ke pelanggan! Status sekarang: Selesai.');
        }

        // 4. Jika status selain di atas, tolak aksi
        return back()->with('error', 'Status pesanan tidak valid untuk aksi kurir saat ini.');
    }

    // ==========================================================
    // HELPER: KIRIM WHATSAPP VIA FONNTE API (AUTHORIZATION AKTIF)
    // ==========================================================
    private function kirimWhatsApp($target, $pesan)
    {
        try {
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL            => 'https://api.fonnte.com/send',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_MAXREDIRS      => 10,
                CURLOPT_TIMEOUT        => 15,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST  => 'POST',
                CURLOPT_POSTFIELDS     => [
                    'target'      => $target,
                    'message'     => $pesan,
                    'countryCode' => '62',
                ],
                CURLOPT_HTTPHEADER => [
                    'Authorization: ' . env('FONNTE_TOKEN', ''),
                ],
            ]);
            curl_exec($curl);
            curl_close($curl);
        } catch (\Exception $e) {
        }
    }
}