<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;
use App\Models\Pembayaran;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class AdminController extends Controller
{
    public function dashboard(Request $request)
    {
        $query = Transaction::with(['user', 'layanan', 'pembayaran'])->orderBy('created_at', 'desc');

        if ($request->has('start_date') && $request->has('end_date') && $request->start_date != '' && $request->end_date != '') {
            $start = $request->start_date . ' 00:00:00';
            $end = $request->end_date . ' 23:59:59';
            $query->whereBetween('created_at', [$start, $end]);
        }

        $transaksi = $query->get();
        $transaksi_ids = $transaksi->pluck('id');
        
        $total_pendapatan = Pembayaran::whereIn('transaksi_id', $transaksi_ids)
                                      ->where('status_pembayaran', 'Lunas')
                                      ->sum('total_harga');

        $pesanan_aktif = Transaction::whereIn('status_pengerjaan', ['Menunggu Penjemputan', 'Menunggu Timbangan', 'Sedang Dicuci', 'Sedang Diantar'])->count();
        $laporan_hari_ini = Transaction::with(['user', 'layanan', 'pembayaran'])->whereDate('created_at', Carbon::today())->orderBy('created_at', 'desc')->get();
        
        return view('admin.dashboard', compact('transaksi', 'total_pendapatan', 'pesanan_aktif', 'laporan_hari_ini'));
    }

    public function updateStatus(Request $request, $no_resi)
    {
        $transaksi = Transaction::with(['user', 'pembayaran'])->where('no_resi', $no_resi)->first();
        if($transaksi) {
            if ($request->status == 'Selesai') {
                if (!$transaksi->pembayaran || $transaksi->pembayaran->status_pembayaran != 'Lunas') {
                    return back()->with('error', '⚠️ GAGAL! Pesanan belum LUNAS. Pastikan pembayaran telah diterima sebelum menutup pesanan.');
                }
                $transaksi->waktu_selesai_cuci = now();
            }

            $transaksi->status_pengerjaan = $request->status;
            $transaksi->save();

            if ($transaksi->user && $transaksi->user->no_wa) {
                $pesan = "Halo *{$transaksi->user->name}*!\n\n"
                       . "Cucian Anda No. Resi *{$no_resi}* diperbarui.\n"
                       . "Status: *{$request->status}* ✅\n\n"
                       . "Pantau di: " . url('/lacak');
                $this->kirimWhatsApp($transaksi->user->no_wa, $pesan);
            }
        }
        return back()->with('sukses', 'Status pesanan berhasil diubah!');
    }

    public function konfirmasiLunas($no_resi)
    {
        $transaksi = Transaction::with('pembayaran')->where('no_resi', $no_resi)->first();
        if ($transaksi && $transaksi->pembayaran) {
            $transaksi->pembayaran->update(['status_pembayaran' => 'Lunas']);
            return back()->with('sukses', 'Uang tunai diterima! Pesanan berhasil ditandai LUNAS.');
        }
        return back()->with('error', 'Data pesanan tidak valid.');
    }

    private function faktorial($n) { return ($n <= 1) ? 1 : $n * $this->faktorial($n - 1); }

    public function inputBeratAdmin(Request $request, $no_resi)
    {
        $request->validate(['berat' => 'required|numeric|min:0.1']);
        $transaksi = Transaction::with(['user', 'layanan'])->where('no_resi', $no_resi)->first();
        if (!$transaksi) return back()->with('error', 'Data tidak ditemukan!');

        // 1. ALGORITMA M/M/s (TETAP UTUH 100%)
        $jumlah_siklus = ceil($request->berat / 10); 
        $s = 2; 
        $lambda = Transaction::whereIn('status_pengerjaan', ['Menunggu Penjemputan', 'Menunggu Timbangan', 'Sedang Dicuci'])->count() + 1;
        $mu = 0.25; 
        $rho = $lambda / ($s * $mu);

        if ($rho >= 1) {
            $ewp_mesin_menit = ($jumlah_siklus * 240) + ($request->berat * 15);
        } else {
            $komponen_sum = 0;
            for ($n = 0; $n < $s; $n++) $komponen_sum += (pow(($lambda / $mu), $n) / $this->faktorial($n));
            $komponen_sum += (pow(($lambda / $mu), $s) / ($this->faktorial($s) * (1 - $rho)));
            $P0 = 1 / $komponen_sum;
            $Lq = (pow(($lambda / $mu), $s) * $lambda * $mu * $P0) / ($this->faktorial($s - 1) * pow(($s * $mu) - $lambda, 2));
            
            $Wq = $Lq / $lambda; 
            $W = $Wq + ($jumlah_siklus * 4); 
            $ewp_mesin_menit = round($W * 60) + round($request->berat * 5);
        }

        $nama_layanan = $transaksi->layanan->nama_layanan;
        if ($nama_layanan == 'Cuci Satuan (Karpet)') {
            $ewp_final = 4320;
        } elseif (in_array($nama_layanan, ['Cuci Satuan (Selimut)', 'Cuci Satuan (Mukena)'])) {
            $ewp_final = 1440;
        } elseif ($nama_layanan == 'Cuci Setrika') {
            $antreanSetrika = Transaction::whereHas('layanan', function($q) { $q->where('nama_layanan', 'Cuci Setrika'); })
                ->whereIn('status_pengerjaan', ['Menunggu Penjemputan', 'Menunggu Timbangan', 'Sedang Dicuci', 'Sedang Diantar'])
                ->where('id', '<', $transaksi->id)->count();
            $ewp_final = $ewp_mesin_menit + ($antreanSetrika * 1440) + 1440; 
        } else {
            $ewp_final = $ewp_mesin_menit; 
        }

        if ($transaksi->layanan->harga_satuan) {
            $harga_layanan = $request->berat * $transaksi->layanan->harga_satuan;
        } else {
            $harga_layanan = $request->berat * $transaksi->layanan->harga_per_kg;
        }
        $ongkir = ($transaksi->metode_kirim == 'Antar Jemput') ? 7500 : 0;
        $total_harga = $harga_layanan + $ongkir;

        // 2. 🔥 ANTI ERROR MYSQL: SIMPAN KATA 'READY' UNTUK ONLINE 🔥
        $statusToken = ($transaksi->metode_pembayaran == 'Online') ? 'READY' : null;

        $transaksi->update([
            'total_berat' => $request->berat,
            'ewp_menit' => $ewp_final,
            'status_pengerjaan' => 'Sedang Dicuci',
            'waktu_mulai_cuci' => now(),
        ]);

        Pembayaran::updateOrCreate(
            ['transaksi_id' => $transaksi->id],
            ['total_harga' => $total_harga, 'snap_token' => $statusToken, 'status_pembayaran' => 'Belum Lunas']
        );

        if ($transaksi->user && $transaksi->user->no_wa) {
            $pesan = "Halo *{$transaksi->user->name}*!\n\n"
                   . "Pakaian Anda No. Resi *{$no_resi}* telah ditimbang (*{$request->berat} Kg*).\n"
                   . "Status: *Sedang Dicuci* 🔄\n"
                   . "Total Tagihan: *Rp " . number_format($total_harga, 0, ',', '.') . "*\n\n"
                   . "Silakan login untuk melunasi atau memantau status cucian Anda.\n"
                   . "Pantau di: " . url('/lacak');
            
            $this->kirimWhatsApp($transaksi->user->no_wa, $pesan);
        }

        return back()->with('sukses', "Validasi berhasil! Pesanan siap dicuci.");
    }

    // ==========================================================
    // 🔥 REDIRECT DUITKU (ORDER ID BERSIH TANPA ANGKA TIME) 🔥
    // ==========================================================
    public function redirectDuitku($no_resi)
    {
        $transaksi = Transaction::with(['user', 'pembayaran', 'layanan'])->where('no_resi', $no_resi)->first();
        if (!$transaksi || !$transaksi->pembayaran) {
            return back()->with('error', 'Tagihan belum tersedia.');
        }

        $merchantCode = 'DS33684';
        $merchantKey = '2236dc62fdbdd975c08bfbe1563a2d10';
        $baseUrl = 'https://sandbox.duitku.com/webapi';

        // Order ID murni nomor resi
        $orderId = $no_resi;
        
        $amount = (int) $transaksi->pembayaran->total_harga;

        $signature = md5($merchantCode . $orderId . $amount . $merchantKey);

        $params = [
            'merchantCode'    => $merchantCode,
            'paymentAmount'   => $amount,
            'paymentMethod'   => 'SP', // Pilihan utama: SP = ShopeePay / QRIS
            'merchantOrderId' => $orderId,
            'productDetails'  => 'Pembayaran Laundry ' . $no_resi,
            'email'           => $transaksi->user->email ?? 'pelanggan@tam-laundry.com',
            'phoneNumber'     => $transaksi->user->no_wa,
            'customerVaName'  => substr($transaksi->user->name, 0, 20),
            'callbackUrl'     => url('/duitku/callback'),
            'returnUrl'       => route('struk', ['resi' => $no_resi]),
            'signature'       => $signature,
            'expiryPeriod'    => 1440
        ];

        try {
            // 1. Tembak API v2/inquiry menggunakan channel SP (ShopeePay / QRIS)
            $response = Http::withHeaders([
                'Accept'       => 'application/json',
                'Content-Type' => 'application/json'
            ])->post($baseUrl . '/api/merchant/v2/inquiry', $params);

            $result = $response->json();

            // 2. Jika channel SP offline di Sandbox, otomatis beralih mencoba BC (BCA Virtual Account)
            if (!isset($result['paymentUrl']) || empty($result['paymentUrl'])) {
                $params['paymentMethod'] = 'BC';
                $response = Http::withHeaders([
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json'
                ])->post($baseUrl . '/api/merchant/v2/inquiry', $params);

                $result = $response->json();
            }

            // 3. Langsung arahkan browser ke Payment URL resmi dari Duitku
            if (isset($result['paymentUrl']) && !empty($result['paymentUrl'])) {
                return redirect($result['paymentUrl']);
            } else {
                $errorMsg = $result['Message'] ?? ($result['statusMessage'] ?? json_encode($result));
                return back()->with('error', '⚠️ Duitku menolak transaksi: ' . $errorMsg);
            }
        } catch (\Exception $e) {
            return back()->with('error', '⚠️ Koneksi ke server Duitku terputus: ' . $e->getMessage());
        }
    }

    public function exportCSV(Request $request)
    {
        $fileName = 'Laporan_TAM_Laundry.csv';
        $query = Pembayaran::with(['transaksi.user', 'transaksi.layanan'])->where('status_pembayaran', 'Lunas');

        if ($request->has('start_date') && $request->has('end_date') && $request->start_date != '' && $request->end_date != '') {
            $start = $request->start_date . ' 00:00:00';
            $end = $request->end_date . ' 23:59:59';
            $query->whereHas('transaksi', function($q) use ($start, $end) {
                $q->whereBetween('created_at', [$start, $end]);
            });
        }

        $pembayaran = $query->get();

        $headers = ["Content-type" => "text/csv", "Content-Disposition" => "attachment; filename=$fileName", "Pragma" => "no-cache", "Cache-Control" => "must-revalidate, post-check=0, pre-check=0", "Expires" => "0"];
        $columns = ['No Resi', 'Nama Pelanggan', 'No WhatsApp', 'Jenis Layanan', 'Total Harga', 'Tanggal Lunas'];

        $callback = function() use($pembayaran, $columns) {
            $file = fopen('php://output', 'w');
            fputcsv($file, $columns);
            foreach ($pembayaran as $p) {
                fputcsv($file, [
                    $p->transaksi->no_resi, 
                    $p->transaksi->user->name, 
                    $p->transaksi->user->no_wa, 
                    $p->transaksi->layanan->nama_layanan, 
                    'Rp ' . $p->total_harga,
                    $p->updated_at
                ]);
            }
            fclose($file);
        };
        return response()->stream($callback, 200, $headers);
    }

    public function callbackDuitku(Request $request)
    {
        $merchantCode = env('DUITKU_MERCHANT_CODE');
        $merchantKey = env('DUITKU_MERCHANT_KEY');
        
        $amount = $request->amount;
        $merchantOrderId = $request->merchantOrderId;
        $signature = $request->signature;
        $resultCode = $request->resultCode;

        if (!empty($merchantCode) && !empty($amount) && !empty($merchantOrderId) && !empty($signature)) {
            $calcSignature = md5($merchantCode . $amount . $merchantOrderId . $merchantKey);
            
            if ($signature == $calcSignature) {
                if ($resultCode == '00') {
                    $parts = explode('-', $merchantOrderId);
                    $no_resi = (count($parts) >= 2) ? $parts[0] . '-' . $parts[1] : $merchantOrderId;

                    $transaksi = Transaction::where('no_resi', $no_resi)->first();
                    if ($transaksi && $transaksi->pembayaran) {
                        $transaksi->pembayaran->update(['status_pembayaran' => 'Lunas']);
                        
                        if ($transaksi->user && $transaksi->user->no_wa) {
                            $pesan = "Halo *{$transaksi->user->name}*!\n\n"
                                   . "Pembayaran Anda untuk cucian *#{$no_resi}* sebesar *Rp " . number_format($amount, 0, ',', '.') . "* telah BERHASIL kami terima (LUNAS) ✅.\n\n"
                                   . "Terima kasih atas kepercayaannya!";
                            $this->kirimWhatsApp($transaksi->user->no_wa, $pesan);
                        }
                    }
                }
                return response()->json(['status' => 'success'], 200);
            }
        }
        return response()->json(['status' => 'bad signature'], 400);
    }

    // ==========================================================
    // 🔥 FITUR BERSIH-BERSIH: HAPUS PESANAN & TAGIHAN 🔥
    // ==========================================================
    public function hapusPesanan($no_resi)
    {
        $transaksi = Transaction::where('no_resi', $no_resi)->first();
        if ($transaksi) {
            // 1. Hapus data pembayarannya dulu agar MySQL tidak error Foreign Key
            Pembayaran::where('transaksi_id', $transaksi->id)->delete();
            
            // 2. Hapus data transaksinya
            $transaksi->delete();

            return back()->with('sukses', "🗑️ Pesanan $no_resi berhasil dihapus bersih dari sistem!");
        }
        return back()->with('error', 'Pesanan tidak ditemukan.');
    }

    private function kirimWhatsApp($target, $pesan)
    {
        try {
            $curl = curl_init();
            curl_setopt_array($curl, [
                CURLOPT_URL => 'https://api.fonnte.com/send',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => ['target' => $target, 'message' => $pesan, 'countryCode' => '62'],
                CURLOPT_HTTPHEADER => [
                    'Authorization: ' . env('FONNTE_TOKEN', ''),
                ],
            ]);
            curl_exec($curl);
            curl_close($curl);
        } catch (\Exception $e) {}
    }
}